

g++ -g  pblake.cpp -o check

./check
