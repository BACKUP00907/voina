#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include "../blake2/blake2-impl.h"
#include <limits.h>
#include "../blake2/blake2.h"
#include "../blake2/blake2b.c"
using namespace std;


static FORCE_INLINE uint64_t inrotr64(const uint64_t w, const unsigned c);
void inxor3(uint64_t a,uint64_t b,uint64_t c,uint64_t d);
static FORCE_INLINE void inblake2b_increment_counter(blake2b_state *S, uint64_t inc);
void inblakecompress(blake2b_state *S , uint8_t *block);
int inblake2b_update(blake2b_state *S, void *in, size_t inlen);
void inblakefinal (blake2b_state * S,void *in, size_t inlen);
void inxor(int64_t l,int64_t a,int64_t b);

void inblake(void * output, int dop,void* insout){
    // basic init
    void* koutput = malloc(64);
    memcpy(koutput,output,sizeof(output));
    if(dop == 1){
    	FILE* dat ;
    	dat = fopen("komhash.txt","rb");
    	void* koml = malloc(64);
    	fread(koml,64,1,dat);


    	memcpy((char*)koutput + 32,(char*)koml +32,32);
	fclose(dat);
	free(koml);
    }

    //blake inverse function starts
    blake2b_state  S;
    inblakefinal(&S,koutput,dop);
    inblake2b_update(&S,insout,dop);
    free(koutput);


}

int inblake2b_update(blake2b_state *S, void *in, size_t inlen) {
	uint8_t *pin = (uint8_t *)in;
	uint16_t valstro=0; 
	if(inlen >= 1){
		inlen =128;
		S->buflen -= (unsigned int)inlen;
		valstro=256;
	}
	else{
		inlen =68;
		S->buflen -= (unsigned int)inlen;
		valstro=196;
	}
	memcpy((uint8_t*) pin,&S->buf[S->buflen], inlen);
	
	while (inlen <( valstro - BLAKE2B_BLOCKBYTES)) {
		pin -= BLAKE2B_BLOCKBYTES;
		inlen += BLAKE2B_BLOCKBYTES;
		inblake2b_increment_counter(S, BLAKE2B_BLOCKBYTES);
		inblakecompress(S, pin);
	}
	pin -= BLAKE2B_BLOCKBYTES;
	inlen += BLAKE2B_BLOCKBYTES;
	inblakecompress(S, S->buf);
	inblake2b_increment_counter(S, BLAKE2B_BLOCKBYTES);
	memcpy(pin,&S->buf[0], BLAKE2B_BLOCKBYTES);
	return 0;
}

void inblakefinal (blake2b_state * S,void *in, size_t inlen){
	//getting template
	FILE* dat ;
	if (inlen>=1){
    		dat = fopen("256.txt","rb");
	}
	else{
		dat = fopen("196.txt","rb");
	}
        fread(S,sizeof(blake2b_state),1,dat);
	fclose(dat);

	//replaceing template hash with hash whose origin has to be calculated
	uint8_t* buffer = (uint8_t*) in;
	int  i=0; 
	for (i = 0; i < 8; ++i) { /* Output full hash to temp buffer */
		memcpy(&S->h[i],buffer+(8*i),8);
	}
	

	inblakecompress(S ,S->buf);
	memset(&S->buf[S->buflen], 0, BLAKE2B_BLOCKBYTES - S->buflen); /* Padding */
	if (inlen>=1){
		FILE* datk;
		datk = fopen("dre.txt","rb");
        	blake2b_state koml ;
        	fread(&koml,sizeof(blake2b_state),1,datk);
		S->f[0]=koml.f[0];
		S->f[1]=koml.f[1];
		fclose(datk);
	}
	else{
		FILE* datk;
		datk = fopen("dre1.txt","rb");
        	blake2b_state koml ;
        	fread(&koml,sizeof(blake2b_state),1,datk);
		S->f[0]=koml.f[0];
		S->f[1]=koml.f[1];
		fclose(datk);
	}


	inblake2b_increment_counter(S,S->buflen);

}

void inblakecompress(blake2b_state *S , uint8_t *block){
	// l is a ;m is b; n is c ; o is d 
	uint64_t m[16] ={0};
	uint64_t v[16]={0};

#define inG( r,  i,  a,  b,  c,  d,  g,  h,  j,  k)                                          \
    do { 									\
		uint64_t ax =0;                 \
        	uint64_t ab =0;                 \
        	b = inrotr64(b, 63) ^c;         \
        	c = c - d;                      \
        	d = inrotr64(d, 16)^g;          \
        	ax = a - b;                      \
        	b = inrotr64(b , 24)^ c;            \
        	d = c- j;                           \
        	ab = inrotr64(d, 32) ^ k ;           \
        	m[blake2b_sigma[r][2 * i + 1]]= ax - ab;    \
        	ab=ab-b;                                      \
        	m[(blake2b_sigma[(r)][2 * (i) + 0])] = (((ab & (uint64_t)0x1) ==0 )? ab/2: ((ab-1)/2));	     \
        	a = (((ab & (uint64_t)0x1) ==0 )? ab/2: ((ab-1)/2)+1);\
        	c=j;\
        	\
    } while ((void)0, 0)
    
#define inGr( r,  i,  a,  b,  c,  d,  g,  h,  j,  k)                                          \
    do { 									\
		uint64_t ax =0;                 \
        	uint64_t ab =0;                 \
        	b = inrotr64(b, 63) ^c;         \
        	c = c - d;                      \
        	d = inrotr64(d, 16)^g;          \
        	ax = a - b;                      \
        	b = inrotr64(b , 24)^ c;            \
            	d = (((c & (uint64_t)0x1) ==0 )? c/2: ((c-1)/2)+1);                          \
            	c = (((c & (uint64_t)0x1) ==0 )? c/2: ((c-1)/2));\
            	inxor(inrotr64(d, 32),ab,d);                            \
        	m[blake2b_sigma[r][2 * i + 1]]= ax - ab;    \
        	ab=ab-b;                                      \
        	m[(blake2b_sigma[(r)][2 * (i) + 0])] = (((ab & (uint64_t)0x1) ==0 )? ab/2: ((ab-1)/2));	     \
        	a = (((ab & (uint64_t)0x1) ==0 )? ab/2: ((ab-1)/2)+1);\
    } while ((void)0, 0)

#define ikROUND(r)                                                               											\
    do {  																\
		inGr((r), 7, v[3], v[4], v[9], v[14], v[3], v[4], (uint64_t)0x0, (uint64_t)0x0);         \
		inGr((r), 6, v[2], v[7], v[8], v[13], v[2], v[7], (uint64_t)0x0, (uint64_t)0x0);         \
		inGr((r), 5, v[1], v[6], v[11], v[12], v[1], v[6], (uint64_t)0x0, (uint64_t)0x0);         \
		inGr((r), 4, v[0], v[5], v[10], v[15], v[0], v[5], (uint64_t)0x0, (uint64_t)0x0);         \
															\
		inG((r), 3, v[3], v[7], v[11], v[15], v[3], v[7], blake2b_IV[3], (blake2b_IV[7] ^ S->f[1]));         \
		inG((r), 2, v[2], v[6], v[10], v[14], v[2], v[6], blake2b_IV[2], (blake2b_IV[6] ^ S->f[0]));         \
		inG((r), 1, v[1], v[5], v[9], v[13], v[1], v[5], blake2b_IV[1], (blake2b_IV[5] ^ S->t[1]));    \
        	inG((r), 0, v[0], v[4], v[8], v[12], v[0], v[4], blake2b_IV[0],  (blake2b_IV[4] ^ S->t[0]));                                \
    }	while ((void)0, 0)


	
	unsigned int i, r;

	

	
	
	inxor3(S->h[7] , S->h[7], v[7], v[15]);
	inxor3(S->h[6] , S->h[6], v[6], v[14]);
	inxor3(S->h[5] , S->h[5], v[5], v[13]);
	inxor3(S->h[4] , S->h[4], v[4], v[12]);
	inxor3(S->h[3] , S->h[3], v[3], v[11]);
	inxor3(S->h[2] , S->h[2], v[2], v[10]);
	inxor3(S->h[1] , S->h[1], v[1], v[9]);
	inxor3(S->h[0] , S->h[0], v[0], v[8]);

	ikROUND(11);
	ikROUND(10);
	ikROUND(9);
	ikROUND(8);
	ikROUND(7);
	ikROUND(6);
	ikROUND(5);
	ikROUND(4);
	ikROUND(3);
	ikROUND(2);
	ikROUND(1);
	ikROUND(0);

	 
	S->h[0] = v[0];
	S->h[1] = v[1];
	S->h[2] = v[2];
	S->h[3] = v[3];
	S->h[4] = v[4];
	S->h[5] = v[5];
	S->h[6] = v[6];
	S->h[7] = v[7];

	memcpy(block + 0 * sizeof(m[0]), &m[0], sizeof(m[0]));
	memcpy(block + 1 * sizeof(m[1]), &m[1], sizeof(m[1]));
	memcpy(block + 2 * sizeof(m[2]), &m[2], sizeof(m[2]));
	memcpy(block + 3 * sizeof(m[3]), &m[3], sizeof(m[3]));
	memcpy(block + 4 * sizeof(m[4]), &m[4], sizeof(m[4]));
	memcpy(block + 5 * sizeof(m[5]), &m[5], sizeof(m[5]));
	memcpy(block + 6 * sizeof(m[6]), &m[6], sizeof(m[6]));
	memcpy(block + 7 * sizeof(m[7]), &m[7], sizeof(m[7]));
	memcpy(block + 8 * sizeof(m[8]), &m[8], sizeof(m[8]));
	memcpy(block + 9 * sizeof(m[9]), &m[9], sizeof(m[9]));
	memcpy(block + 10 * sizeof(m[10]), &m[10], sizeof(m[10]));
	memcpy(block + 11 * sizeof(m[11]), &m[11], sizeof(m[11]));
	memcpy(block + 12 * sizeof(m[12]), &m[12], sizeof(m[12]));
	memcpy(block + 13 * sizeof(m[13]), &m[13], sizeof(m[13]));
	memcpy(block + 14 * sizeof(m[14]), &m[14], sizeof(m[14]));
	memcpy(block + 15 * sizeof(m[15]), &m[15], sizeof(m[15]));



	

	

#undef ikROUND 
#undef inG
}


void inxor3(uint64_t a,uint64_t b,uint64_t c,uint64_t d){
	int k= 0;

	while(k<sizeof(a)*8){
		if (a & (0x1<<k)){
			b &= 0x1<<k;
			c &= 0x0<<k;
			d |= 0x0<<k;
		}
		else{
			b |= 0x0<<k;
			c |= 0x1<<k;
			d &= 0x1<<k;

		}

		k+=1;
	}




}

void inxor(int64_t l,int64_t a,int64_t b){
	int k= 0;

	while(k<sizeof(l)*8){
		if (l & (0x1 <<k)){
			a |= 0x1 <<k;
			b &= 0x0 <<k;
			
		}
		else{
			b |= 0x1 <<k;
			a |= 0x1 <<k;

		}

		k+=1;
	}
}

static FORCE_INLINE uint64_t inrotr64(const uint64_t w, const unsigned c) {
	return (w << c) | (w >> (64 - c));
}

static FORCE_INLINE void inblake2b_increment_counter(blake2b_state *S, uint64_t inc) {
	S->t[1] -= (S->t[0] < inc);
	S->t[0] -= inc;
}


int main(){
 	void * kor = malloc(256);
 	FILE * drc;
 	drc = fopen("RN.txt","rb");
 	fread(kor,256,1,drc);
 	fclose(drc);

 	void * kor2 = malloc(256);

 	void* hash1; 
 	void* hash2;
 	hash1 =malloc(64);
 	hash2 =malloc(64);
 	memset(kor2,0,256);

 	blake2b(hash1, 64, kor, 256, nullptr, 0);
 	inblake(hash1, 2,kor2);
 	blake2b(hash2, 64, kor2, 256, nullptr, 0);
	int j =0;
	while(j<64){
		if( *(((uint8_t*)hash1)+j)   == *((uint8_t*)hash2 +j)) {
				printf("TRUE\n");
		}
		else{
			printf("FALSE\n");
		}
		



		j++;
	}
	
	j=0;
	while(j<64){
		printf("%X",*((uint8_t*)hash1 +j));
		j++;
	}
	printf("\n\n\n");
	
	j=0;
	while(j<64){
		printf("%X",*((uint8_t*)hash2 +j));
		j++;
	}
    return 0;
}
