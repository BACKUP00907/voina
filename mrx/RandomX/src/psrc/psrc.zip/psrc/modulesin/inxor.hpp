#ifndef INXOR_H
#define INXOR_H
#include <stdint.h>
#include <limits.h>

using namespace std;

void setat(uint64_t &num, uint64_t k );

void rsetat(uint64_t &num, uint64_t k ,int x);

void lsetat(uint64_t &num, uint64_t k ,int x);

void dsetat(uint64_t &num, uint64_t k);

void ldsetat(uint64_t &num, uint64_t k ,int x);

void rdsetat(uint64_t &num, uint64_t k ,int x);
//above taken 

void inxori(uint64_t a, int x,uint64_t *b1,uint64_t *c1);

void dsetN2(uint64_t &num1 , uint64_t &num2,uint64_t k, uint64_t &rec1, uint64_t &rec2,int x);

void setN2(uint64_t &num1 , uint64_t &num2,uint64_t k, uint64_t &rec1, uint64_t &rec2,int x);

void dsetN1(uint64_t &num1 , uint64_t &num2,uint64_t k, uint64_t &rec1, uint64_t &rec2,int x);

void setN1(uint64_t &num1 , uint64_t &num2,uint64_t k, uint64_t &rec1, uint64_t &rec2,int x);


#endif
