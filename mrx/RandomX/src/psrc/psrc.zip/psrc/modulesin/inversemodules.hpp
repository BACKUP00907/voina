#ifndef INMODULES_H
#define INMODULES_H

#include "inxor.hpp"

#endif
