#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <limits.h>
#include <stdint.h>
#include "inxor.hpp"

using namespace std;
uint64_t roit(const uint64_t w, const unsigned c) {
	return (w >> c) | (w << (64 - c));
}

int main(){
	uint64_t wjil =0;
	FILE * XPA;
	int kio =1;
	uint64_t kkorl =0xD135C21BC9DB5466;
	uint64_t lop=0;
	
	uint64_t kkorl1 =0;
 	uint64_t kkorl2 =0;
 	
 	uint64_t tcount =0;
 	
 	uint64_t contr =1;
 	
 	
	
 	while(contr < 2){		
 		while(tcount < 1){
 				
 			lop = kkorl ^ roit(kkorl ,kio);
 		
 			kkorl1 =0;
 			kkorl2 =0;
 	
 	
 			inxori(lop,kio,&kkorl1,&kkorl2);
 			printf("%lX",lop ^ kkorl1 ^ kkorl2);
 			tcount++;
 			
 		}
 		contr ++;
 		kio++;
 	}	
    return 0;
}
