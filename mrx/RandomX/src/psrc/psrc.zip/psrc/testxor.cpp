#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <limits.h>
#include <stdint.h>
#include "../blake2/blake2.h"
#include "../blake2/blake2b.c"
#include "../blake2/blake2-impl.h"

using namespace std;

static FORCE_INLINE uint64_t rot(const uint64_t w, const unsigned c);
static FORCE_INLINE uint64_t inrotr64(const uint64_t w, const unsigned c);
void inxor3(uint64_t a,uint64_t *b1,uint64_t *c1,uint64_t *d1);
void inxor(int64_t l,int64_t a,int64_t b);
void inxori(uint64_t a, int x,uint64_t *b1,uint64_t *c1);

void dsetN2(uint64_t &num1 , uint64_t &num2,uint64_t k, uint64_t &rec1, uint64_t &rec2,int x);

void setN2(uint64_t &num1 , uint64_t &num2,uint64_t k, uint64_t &rec1, uint64_t &rec2,int x);

void dsetN1(uint64_t &num1 , uint64_t &num2,uint64_t k, uint64_t &rec1, uint64_t &rec2,int x);

void setN1(uint64_t &num1 , uint64_t &num2,uint64_t k, uint64_t &rec1, uint64_t &rec2,int x);

void inxor3(uint64_t a,uint64_t *b1,uint64_t *c1,uint64_t *d1){
	int k= 0;
	uint64_t b =0;
	uint64_t c =0;
	uint64_t d =0;
	while(k<sizeof(a)*8){
		if (a & (((uint64_t)0x1)<<k)){
			b |= (uint64_t)(((uint64_t)0x1)<<k);
			
			c |= (uint64_t)(((uint64_t)0x1)<<k);
			
			d |= (uint64_t)(((uint64_t)0x1)<<k);
			printf("1");
		}
		else{
			
			c |= (uint64_t)(((uint64_t)0x1)<<k);
			d &= ~(uint64_t)(((uint64_t)0x1)<<k);
			b |= (uint64_t)(((uint64_t)0x1)<<k);
			printf("0");

		}

		k+=1;
	}

	*b1 =b;
	*c1=c;
	*d1=d;


}

void inxor(int64_t l,int64_t a,int64_t b){
	int k= 0;

	while(k<sizeof(l)*8){
		if (l & (((uint64_t)0x1) <<k)){
			a |= ((uint64_t)0x1) <<k;
			b &= ((uint64_t)0x0) <<k;
			
		}
		else{
			b |= ((uint64_t)0x1) <<k;
			a |= ((uint64_t)0x1) <<k;

		}

		k+=1;
	}
}

void inxori(uint64_t a, int x,uint64_t *b1,uint64_t *c1){
	int k= 0;
	uint64_t b =0;
	uint64_t c =0;
	uint64_t rc =0;
	uint64_t rc2 =0;
	
	uint64_t rec =0;
	uint64_t rec2 =0;
	
	uint64_t kranken =0;
	
	uint64_t bomba =0;
	
	while(k<64){
		
			if(a & ((uint64_t(1))<<k)){
			
				if((rec & ((uint64_t(1))<<k))  && (rec2 & ((uint64_t(1))<<k))){
				}
				else if((rec & ((uint64_t(1))<<k))){
					if((rc & ((uint64_t(1))<<k))){
						dsetN2(rc, rc2,k, rec, rec2,x);
						
					}
					else{
						setN2(rc, rc2,k, rec, rec2,x);
						
					}
				}
				else if((rec2 & ((uint64_t(1))<<k))){
					if((rc2 & ((uint64_t(1))<<k))){
						dsetN1(rc, rc2,k, rec, rec2,x);
						
					}
					else{
						setN1(rc, rc2,k, rec, rec2,x);
						
					}
				}
				else{
				
					kranken |= ((uint64_t)0x1) << k ;
					dsetN2(rc, rc2,k, rec, rec2,x);
					setN1(rc, rc2,k, rec, rec2,x);
				}
			}
			else{
				
			
				if((rec & ((uint64_t(1))<<k))  && (rec2 & ((uint64_t(1))<<k))){
				}
				else if((rec & ((uint64_t(1))<<k))){
					if((rc & ((uint64_t(1))<<k))){
						setN2(rc, rc2,k, rec, rec2,x);
						
					}
					else{
						dsetN2(rc, rc2,k, rec, rec2,x);
						
					}
				}
				else if((rec2 & ((uint64_t(1))<<k))){
					if((rc2 & ((uint64_t(1))<<k))){
						setN1(rc, rc2,k, rec, rec2,x);
						
					}
					else{
						dsetN1(rc, rc2,k, rec, rec2,x);
						
					}
				}
				else{
					kranken |= ((uint64_t)0x1) << k ;
					setN2(rc, rc2,k, rec, rec2,x);
					setN1(rc, rc2,k, rec, rec2,x);
				
				
				}
			
			}
		
		
		
		k++;
		
	
	}
	
	if((rc^rc2^a ) ==0){
		*b1= rc;
		*c1= rc2;
		return;
	}


	while(bomba < (kranken +1)){
		k=0;
		rec= 0;
		rec2=0;
		while(k<64){
		
			if(a & ((uint64_t(1))<<k)){
			
				if((rec & ((uint64_t(1))<<k))  && (rec2 & ((uint64_t(1))<<k))){
				}
				else if((rec & ((uint64_t(1))<<k))){
					if((rc & ((uint64_t(1))<<k))){
						dsetN2(rc, rc2,k, rec, rec2,x);
						
					}
					else{
						setN2(rc, rc2,k, rec, rec2,x);
						
					}
				}
				else if((rec2 & ((uint64_t(1))<<k))){
					if((rc2 & ((uint64_t(1))<<k))){
						dsetN1(rc, rc2,k, rec, rec2,x);
						
					}
					else{
						setN1(rc, rc2,k, rec, rec2,x);
						
					}
				}
				else{
				
					
					if((bomba & ((uint64_t(1))<<k))){
						setN2(rc, rc2,k, rec, rec2,x);
						dsetN1(rc, rc2,k, rec, rec2,x);
					}
					else{
						dsetN2(rc, rc2,k, rec, rec2,x);
						setN1(rc, rc2,k, rec, rec2,x);
					}
				}
			}
			else{
				
			
				if((rec & ((uint64_t(1))<<k))  && (rec2 & ((uint64_t(1))<<k))){
				}
				else if((rec & ((uint64_t(1))<<k))){
					if((rc & ((uint64_t(1))<<k))){
						setN2(rc, rc2,k, rec, rec2,x);
						
					}
					else{
						dsetN2(rc, rc2,k, rec, rec2,x);
						
					}
				}
				else if((rec2 & ((uint64_t(1))<<k))){
					if((rc2 & ((uint64_t(1))<<k))){
						setN1(rc, rc2,k, rec, rec2,x);
						
					}
					else{
						dsetN1(rc, rc2,k, rec, rec2,x);
						
					}
				}
				else{
					if((bomba & ((uint64_t(1))<<k))){
						dsetN2(rc, rc2,k, rec, rec2,x);
						dsetN1(rc, rc2,k, rec, rec2,x);
					}
					else{
						setN2(rc, rc2,k, rec, rec2,x);
						setN1(rc, rc2,k, rec, rec2,x);
					}
					
				
				
				}
			
			}
		
		
		
			k++;
		
	
		}
		
		if((rc^rc2^a ) ==0){
			*b1= rc;
			*c1= rc2;
			return;
		}
		
		
		bomba++;
	}
		
}


void setat(uint64_t &num, uint64_t k ){
	 num |= (uint64_t(1) << k);
}

void rsetat(uint64_t &num, uint64_t k ,int x){
	 num |= rot(((uint64_t(1) << k)),x);
}

void lsetat(uint64_t &num, uint64_t k ,int x){
	 num |= inrotr64(((uint64_t(1) << k)),x);
}


void dsetat(uint64_t &num, uint64_t k){
	 num &= ~(uint64_t(1) << k);
}

void ldsetat(uint64_t &num, uint64_t k ,int x){
	 num &= inrotr64((~(uint64_t(1) << k)),x);
}

void rdsetat(uint64_t &num, uint64_t k ,int x){
	 num &= rot((~(uint64_t(1) << k)),x);
}


void setN1(uint64_t &num1 , uint64_t &num2,uint64_t k, uint64_t &rec1, uint64_t &rec2,int x){
	setat(num1, k);
	setat(rec1, k);
	
	rsetat(num2, k,x);
	rsetat(rec2, k,x);

}

void setN2(uint64_t &num1 , uint64_t &num2,uint64_t k, uint64_t &rec1, uint64_t &rec2,int x){
	setat(num2, k);
	setat(rec2, k);
	
	lsetat(num1, k,x);
	lsetat(rec1, k,x);

}


void dsetN1(uint64_t &num1 , uint64_t &num2,uint64_t k, uint64_t &rec1, uint64_t &rec2,int x){
	dsetat(num1, k);
	setat(rec1, k);
	
	rdsetat(num2, k,x);
	rsetat(rec2, k,x);

}

void dsetN2(uint64_t &num1 , uint64_t &num2,uint64_t k, uint64_t &rec1, uint64_t &rec2,int x){
	dsetat(num2, k);
	setat(rec2, k);
	
	ldsetat(num1, k,x);
	lsetat(rec1, k,x);

}

static FORCE_INLINE uint64_t inrotr64(const uint64_t w, const unsigned c) {
	return (w << c) | (w >> (64 - c));
}

static FORCE_INLINE uint64_t rot(const uint64_t w, const unsigned c) {
	return (w >> c) | (w << (64 - c));
}



int main(){
	uint64_t wjil =0;
	FILE * XPA;
	int kio =1;
	uint64_t kkorl =0xD135C21BC9DB5466;
	uint64_t lop=0;
	
	uint64_t kkorl1 =0;
 	uint64_t kkorl2 =0;
 	
 	uint64_t tcount =0;
 	
 	uint64_t contr =1;
 	
 	
	
 	while(contr < 60){		
 		while(tcount < 100000000){
 				
 			lop = kkorl ^ rot(kkorl ,kio);
 		
 			kkorl1 =0;
 			kkorl2 =0;
 	
 	
 			inxori(lop,kio,&kkorl1,&kkorl2);
 			tcount++;
 			
 		}
 		contr ++;
 		kio++;
 	}	
    return 0;
}
